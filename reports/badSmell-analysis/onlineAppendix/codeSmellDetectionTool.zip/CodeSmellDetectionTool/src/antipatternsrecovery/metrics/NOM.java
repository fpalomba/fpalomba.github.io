package antipatternsrecovery.metrics;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;

public class NOM {

	public int computeNOM(ICompilationUnit pClass) {
		int counter = 0;

		if(pClass.exists()) {
			try {
				for(IType type: pClass.getTypes()){
					for(@SuppressWarnings("unused") IMethod method: type.getMethods()) {
						counter++;
					}
				}
			} catch (JavaModelException e) {
				e.printStackTrace();
			}
		}
		return counter;
	}
}
