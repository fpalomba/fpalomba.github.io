package antipatternsrecovery.metrics;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LOC {

	/**
	 * Computing lines of code for both classes and methods.
	 * @param pFeature: the string representation of the class/method
	 * @return lines of code
	 */
	public int computeLOC(String pFeature) {
		int loc=0;
		String regex="[\n]";
		
		Pattern pattern=Pattern.compile(regex);
		Matcher matcher = pattern.matcher(pFeature);
		
		while (matcher.find()) 
			loc++;		    
		
		return loc+1;
	}
}