package antipatternsrecovery.beans;

import java.util.Collection;
import java.util.Vector;

public class PackageBean {
	private String name;
	private Collection<ClassBean> classes;
	
	
	public PackageBean()
	{
		name = null;
		classes = new Vector<ClassBean>();
	}
	
	
	public String getName() {
		return this.name;
	}

	public void setName(String pName) {
		this.name = pName;
	}

	public Collection<ClassBean> getClasses() {
		return this.classes;
	}

	public void setClasses(Collection<ClassBean> pClasses) {
		this.classes = pClasses;
	}
	
	public void addClass(ClassBean pClass){
		classes.add(pClass);
	}
	
	public void removeClass(ClassBean pClass){
		classes.remove(pClass);
	}

}
