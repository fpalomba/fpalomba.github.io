package antipatternsrecovery.beans;

public class InstanceVariableBean {
	
	private String visibility;
	private String type;
	private String name;
	private String initialization;
	private ClassBean belongingClass;
	
	public InstanceVariableBean() {
		visibility = null;
		type = null;
		name = null;
		initialization = null;
	}
	
	public String getVisibility() {
		return visibility;
	}
	
	public void setVisibility(String pVisibility) {
		visibility = pVisibility;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String pType) {
		type = pType;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String pName) {
		name = pName;
	}
	
	public String getInitialization() {
		return initialization;
	}
	
	public void setBelongingClass(ClassBean pClass) {
		belongingClass = pClass;
	}
	
	public ClassBean getBelongingClass() {
		return belongingClass;
	}
	
	public void setInitialization(String pInitialization) {
		initialization = pInitialization;
	}
	
	public String toString() {
		return "(" + visibility + "|" + type + "|" + name + "|" + initialization + ")";
	}
	
}
