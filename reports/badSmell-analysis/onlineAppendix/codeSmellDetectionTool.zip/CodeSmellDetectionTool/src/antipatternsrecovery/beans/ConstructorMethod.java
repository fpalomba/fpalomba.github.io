package antipatternsrecovery.beans;

import org.eclipse.jdt.core.IMethod;

public class ConstructorMethod {
	
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public IMethod getImethod() {
		return imethod;
	}
	public void setImethod(IMethod imethod) {
		this.imethod = imethod;
	}
	public boolean isDefaultConstructor() {
		return isDefaultConstructor;
	}
	public void setDefaultConstructor(boolean isDefaultConstructor) {
		this.isDefaultConstructor = isDefaultConstructor;
	}
	
	
	private String source;
	private IMethod imethod;
	private boolean isDefaultConstructor;
	
}
