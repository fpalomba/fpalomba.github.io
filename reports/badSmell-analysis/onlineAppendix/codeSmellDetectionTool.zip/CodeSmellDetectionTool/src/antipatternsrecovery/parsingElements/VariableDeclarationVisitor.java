package antipatternsrecovery.parsingElements;

import java.util.ArrayList;
import java.util.Collection;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;

public class VariableDeclarationVisitor extends ASTVisitor {
	private	Collection<VariableDeclarationFragment> variables = new ArrayList<VariableDeclarationFragment>();
	
	@Override
		public boolean visit(VariableDeclarationFragment node) {
			variables.add(node);	
	
		  return super.visit(node);
		}

	/**
	 * This method allows to get all the FieldDeclaration for the Class on which it is;
	 * 
	 * @return
	 * 				a List of all FieldDeclaration;
	 */
		public Collection<VariableDeclarationFragment> getFields() {
			return variables;
		}
}
