package antipatternsrecovery.parsingElements;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.PackageDeclaration;

public class PackageVisitor extends ASTVisitor {
	
	private PackageDeclaration packageDeclaration;
	
	public PackageVisitor(PackageDeclaration x){
		javax.swing.JOptionPane.showMessageDialog(null, "Entro in PackageVisitor...");
		setPackageDeclaration(x);
	}
	
	public boolean visit(PackageDeclaration x) {
		javax.swing.JOptionPane.showMessageDialog(null, "Effettuo una visita in PackageVisitor...");
		setPackageDeclaration(x);
		return false;
	}

	public PackageDeclaration getPackageDeclaration() {
		return packageDeclaration;
	}

	public void setPackageDeclaration(PackageDeclaration packageDeclaration) {
		this.packageDeclaration = packageDeclaration;
	}	
}