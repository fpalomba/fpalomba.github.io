package antipatternsrecovery.parsingElements;

import org.eclipse.jdt.core.dom.PackageDeclaration;

import antipatternsrecovery.beans.PackageBean;

public class PackageParser {
	
	public static PackageBean parse(PackageDeclaration p) {
		PackageBean pp = new PackageBean();
		pp.setName(p.getName().toString());
		return pp;
	}
}