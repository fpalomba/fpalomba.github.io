package antipatternsrecovery.parsingElements;

import org.eclipse.jdt.core.dom.MethodInvocation;

import antipatternsrecovery.beans.MethodBean;

public class InvocationParser {
	public static MethodBean parse(String pInvocationName) {
		MethodBean methodBean = new MethodBean();
		methodBean.setName(pInvocationName);
		return methodBean;
	}
	
	public static MethodBean parse(MethodInvocation pMethodInvocation) {
		MethodBean methodBean = new MethodBean();
		methodBean.setName(pMethodInvocation.getName().getIdentifier());
		return methodBean;
	}
}