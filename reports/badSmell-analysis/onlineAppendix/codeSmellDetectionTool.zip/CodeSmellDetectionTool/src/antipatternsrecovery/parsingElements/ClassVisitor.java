package antipatternsrecovery.parsingElements;

import java.util.Collection;
import java.util.List;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

public class ClassVisitor extends ASTVisitor {
	
	private Collection<TypeDeclaration> classNodes;
	
	public ClassVisitor(Collection<TypeDeclaration> pClassNodes) {
		classNodes = pClassNodes;
	}
	
	public boolean visit(TypeDeclaration pClassNode) {
		classNodes.add(pClassNode);
		return true;
	}
	
	public Collection<TypeDeclaration> getMethods() {
		return classNodes;
	}
}
